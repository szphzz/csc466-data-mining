import pandas as pd
import numpy as np
from scipy.sparse import lil_matrix

class CF():
    def __init__(self, user=-1, joke=-1, sim=0, formula=0, N=0):
        self.jester = pd.read_csv('/Users/sophiapchung/Desktop/CSC466/Lab5/jester-data-1.csv', header=None)
        self.jokes_per_user = self.jester.iloc[:, 0]
        self.og_ratings_matrix = lil_matrix(self.jester.iloc[:, 1:])
        self.avg_user_ratings = []
        for i in range(len(self.jester)):
            row = self.og_ratings_matrix[i].toarray()[0]
            ratings = [rating for rating in row if rating != 99]
            self.avg_user_ratings.append(sum(ratings) / self.jokes_per_user[i])

        self.user = user # between 1 and 24983
        self.joke = joke # between 1 and 100
        self.sim = sim # 1 or 2
        self.formula = formula # 1 or 2 or 3
        self.N = N

    def calc_sim(self, user1, user2):
        row1 = self.og_ratings_matrix[user1 - 1].toarray()[0]
        row2 = self.og_ratings_matrix[user2 - 1].toarray()[0]

        common_jokes = []
        for i in range(1, 101):
            if (row1[i - 1] != 99) and (row2[i - 1] != 99):
                common_jokes.append(i)

        if self.sim == 1: # pearson correlation
            list1 = [row1[j - 1] - self.avg_user_ratings[user1 - 1] for j in common_jokes]
            list2 = [row2[j - 1] - self.avg_user_ratings[user2 - 1] for j in common_jokes]
        if self.sim == 2: # cosine similarity
            list1 = [row1[j - 1] for j in common_jokes]
            list2 = [row2[j - 1] for j in common_jokes]

        arr1 = np.array(list1)
        arr2 = np.array(list2)

        sim = np.sum(arr1 * arr2) / np.sqrt(np.sum(arr1 ** 2) * np.sum(arr2 ** 2))
        return sim

    def updated_ratings_matrix(self):
        if self.og_ratings_matrix[self.user - 1, self.joke - 1] == 99:
            return self.og_ratings_matrix
        else:
            ratings_matrix = self.og_ratings_matrix.copy()
            ratings_matrix[self.user - 1, self.joke - 1] = 99
            return ratings_matrix

    def n_nearest_neighbors(self):
        dists = []
        ratings_matrix = self.updated_ratings_matrix()
        for other_user in range(1, ratings_matrix.shape[0] + 1):
            if other_user != self.user:
                dists.append(self.calc_sim(self.user, other_user))
        
        neighbors = np.argsort(dists)[self.N:]
        return neighbors
    
    def predict_rating(self):
        neighbors = self.n_nearest_neighbors()
        sims = []
        multipliers = []
        for n in neighbors:
            sims.append(self.calc_sim(self.user, n))
            if self.formula == 1: # weighted sum
                multipliers.append(self.og_ratings_matrix[n - 1].toarray()[0][self.joke - 1])
            if self.formula == 2: # adjusted weighted sum
                multipliers.append(self.og_ratings_matrix[n - 1].toarray()[0][self.joke - 1] - self.avg_user_ratings[n - 1])
        
        sims = np.array(sims)
        multipliers = np.array(multipliers)
        
        k = 1 / np.sum(np.abs(sims))
        if self.formula == 1: # weighted sum
            rating = k * np.sum(sims * multipliers)
        if self.formula == 2: # adjusted weighted sum
            rating = self.avg_user_ratings[self.user] + k * np.sum(sims * multipliers)
        return rating

def method1(user, joke): # pearson x weighted
    cf = CF(user, joke, 1, 1, 5)
    return cf.predict_rating()

def method2(user, joke): # cosine x weighted
    cf = CF(user, joke, 2, 1, 5)
    return cf.predict_rating()

def method3(user, joke): # pearson x adjusted
    cf = CF(user, joke, 1, 2, 5)
    return cf.predict_rating()

def method4(user, joke): # cosine x adjusted
    cf = CF(user, joke, 2, 2, 5)
    return cf.predict_rating()