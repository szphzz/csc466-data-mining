from lab5 import *
import sys

def evaluate_list(method, lst):
    cf = CF()
    valid = []
    for pair in lst:
        if cf.og_ratings_matrix.getrow(pair[0]).toarray().tolist()[0][pair[1]] != 99:
            valid.append(pair)
    
    print('userID, itemID, Actual_Rating, Predicted_Rating, Delta_Rating')

    preds = []
    actuals = []
    all_norms = []
    deltas = []
    maes = []

    for pair in valid:
        if method == 1:
            pred = method1(pair[0], pair[1])
        if method == 2:
            pred = method2(pair[0], pair[1])
        if method == 3:
            pred = method3(pair[0], pair[1])
        if method == 4:
            pred = method4(pair[0], pair[1])

        preds.append(pred)
        actual = cf.og_ratings_matrix.getrow(pair[0] - 1).toarray().tolist()[0][pair[1] - 1]
        actuals.append(actual)
    
    # normalize preds
    norms = [((rating - min(preds)) * (10 + 10)) / (max(preds) - min(preds)) - 10 for rating in preds]
    for norm in norms:
        all_norms.append(norm)

    actuals = np.array(actuals)
    norms = np.array(norms)
    deltas = actuals - norms

    case = 0
    for pair in valid:
        print(f"{pair[0]}, {pair[1]}, {actuals[case]}, {norms[case]}, {deltas[case]}")
        case += 1

    mae = np.sum(np.abs(deltas)) / len(valid)
    maes.append(mae)
    print(f"MAE: {mae}")
    print('\n-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n')

    recs = [score >= 5 for score in all_norms]
    truths = [score >= 5 for score in actuals]
    cf_matrix = pd.crosstab(truths, recs, rownames=['Actual'], colnames=['Predicted'])

    RR = cf_matrix.iloc[1, 1]
    RN = cf_matrix.iloc[1, 0]
    FP = cf_matrix.iloc[0, 1]
    NN = cf_matrix.iloc[0, 0]
    precision =  RR / (RR + FP)
    recall = RR / (RR + RN)
    f1_score = (2 * precision * recall) / (precision + recall)
    overall_acc = (RR + NN) / (RR + RN + FP + NN)

    print('Confusion matrix:')
    print(cf_matrix)
    print(f"Precision: {precision}")
    print(f"Recall: {recall}")
    print(f"F1 score: {f1_score}")
    print(f"Overall accuracy: {overall_acc}")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print('Incorrect input :(')
        print('Method parameter options:')
        print('1. Pearson correlation x weighted sum')
        print('2. Cosine similarity x weighted sum')
        print('3. Pearson correlation x adjusted weighted sum')
        print('4. Cosine similarity x adjusted weighted sum')
        sys.exit()
    method = int(sys.argv[1])
    df = pd.read_csv(sys.argv[2])
    lst = list(zip(df.iloc[:,0], df.iloc[:,1]))
    evaluate_list(method, lst)