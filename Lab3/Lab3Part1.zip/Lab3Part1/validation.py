import pandas as pd
import sys
from InduceC45 import DecisionTreeClassifier
from classify import classify
import random
import numpy as np
 
def cv_split(indices, n):
    random.shuffle(indices)
    return [indices[i::n] for i in range(n)]
    
if __name__ == '__main__':
    # from command line
    if (len(sys.argv) < 3) or (len(sys.argv) > 4):
        print('Wrong format')
        sys.exit(1)

    csv_file = sys.argv[1]
    before = csv_file.split('.csv')[0]
    dataset = before.split('/')[-1]

    # optional restrictions file
    if len(sys.argv) == 4:
        restrictions_file = sys.argv[2] 
        n = int(sys.argv[3])
    else:
        restrictions_file = None
        n = int(sys.argv[2])

    # getting folds if n > 0
    training = pd.read_csv(csv_file)
    indices = list(training.index.values)[1:]
    folds = cv_split(indices, n)

    # run C4.5
    if restrictions_file is None: # drop last col
        A = list(training.columns)[:-1]
    else:
        restrict = open(restrictions_file, 'r').read().split(',')
        restrict = [int(r) for r in restrict]

        A = []
        for index, a in enumerate(training.columns):
            if restrict[index] == 1:
                A.append(a)

    if n == 0:
        D = pd.read_csv(csv_file)
        og_D = D.copy()
        classifier = DecisionTreeClassifier()
        T = classifier.C45(D, A, og_D, threshold=0.1)
        T = {'dataset': csv_file, 'node': T}

        y_pred = []
        y = training.iloc[:,-1] 
        correct = 0
        incorrect = 0
        for i in range(len(training)):
            actual = y[i]
            data = training.iloc[i, :-1].to_dict()
            pred = classify(data, T['node'])
            if actual == pred:
                correct += 1
            else:
                incorrect +=1
            y_pred.append(pred)

        cf_matrix = pd.crosstab(y, y_pred, rownames=['Actual'], colnames=['Predicted'])

        file_name = dataset + '.out'
        with open(file_name, 'w') as file:
            file.write('Overall confusion matrix: ' + '\n')
            file.write(str(cf_matrix) + '\n')
            i = 0
            for label in cf_matrix.index:
                TP = cf_matrix.iloc[i, i]
                FP = np.sum(cf_matrix.iloc[:, i]) - TP
                FN = np.sum(cf_matrix.iloc[i, :]) - TP
                TN = cf_matrix.values.sum() - TP - FP - FN
                file.write('\n' + "For class label '" + str(label) + "': " + '\n')
                file.write('Confusion matrix: ' + '\n')
                temp = [[TP, FP], 
                        [FN, TN]]
                for row in temp:
                    file.write(str(row) + '\n')
                file.write('Recall: ' + str(TP / (TP + FN)) + '\n')
                file.write('Precision: ' + str(TP / (TP + FP)) + '\n')
                i += 1
            file.write('\n' + 'Overall accuracy: ' + str(correct/len(training)) + '\n')
            file.write('Overall error rate: ' + str(incorrect/len(training)) + '\n')
           
    elif n == -1:
        correct_counts = []
        incorrect_counts = []
        accuracies = []
        errors = []
        cf_matrices = []

        for i in range(len(training)):
            D = training.drop(i, axis=0).reset_index(drop=True)
            og_D = D.copy()
            classifier = DecisionTreeClassifier()
            T = classifier.C45(D, A, og_D, threshold=0.075) # had to lower this here for balloons
            T = {'dataset': csv_file, 'node': T}

            y = D.iloc[:,-1] # assuming input CSV file is a training set
            y_pred = []
            correct = 0
            incorrect = 0
            for i in range(len(D)):
                actual = y[i]
                data = D.iloc[i, :-1].to_dict()
                pred = classify(data, T['node'])
                if actual == pred:
                    correct += 1
                else:
                    incorrect +=1
                y_pred.append(pred)

            correct_counts.append(correct)
            incorrect_counts.append(incorrect)
            cf_matrices.append(pd.crosstab(y, y_pred, rownames=['Actual'], colnames=['Predicted']))
        
        cf_matrix = sum(cf_matrices)

        file_name = dataset + '.out'
        with open(file_name, 'w') as file:
            file.write('Overall confusion matrix: ' + '\n')
            file.write(str(cf_matrix) + '\n')
            i = 0
            for label in cf_matrix.index:
                TP = cf_matrix.iloc[i, i]
                FP = np.sum(cf_matrix.iloc[:, i]) - TP
                FN = np.sum(cf_matrix.iloc[i, :]) - TP
                TN = cf_matrix.values.sum() - TP - FP - FN
                file.write('\n' + "For class label '" + str(label) + "': " + '\n')
                file.write('Confusion matrix: ' + '\n')
                temp = [[TP, FP], 
                        [FN, TN]]
                for row in temp:
                    file.write(str(row) + '\n')
                file.write('Recall: ' + str(TP / (TP + FN)) + '\n')
                file.write('Precision: ' + str(TP / (TP + FP)) + '\n')
                i += 1
            file.write('\n' + 'Overall accuracy: ' + str(sum(correct_counts)/(len(D) * len(training))) + '\n')
            file.write('Overall error rate: ' + str(sum(incorrect_counts)/(len(D) * len(training))) + '\n')
            file.write('Average accuracy: ' + str(sum(accuracies)/len(training)) + '\n')
            file.write('Average error rate: ' + str(sum(errors)/len(training)) + '\n')

    elif n > 0:
        correct_counts = []
        incorrect_counts = []
        accuracies = []
        errors = []
        len_D = []
        cf_matrices = []

        for fold in folds:
            D = training.drop(fold, axis=0).reset_index(drop=True)
            len_D.append(len(D))
            og_D = D.copy()
            classifier = DecisionTreeClassifier()
            T = classifier.C45(D, A, og_D, threshold=0.1)
            T = {'dataset': csv_file, 'node': T}

            y = D.iloc[:,-1] # assuming input CSV file is a training set
            y_pred = []
            correct = 0
            incorrect = 0
            for i in range(len(D)):
                actual = y[i]
                data = D.iloc[i, :-1].to_dict()
                pred = classify(data, T['node'])
                if actual == pred:
                    correct += 1
                else:
                    incorrect +=1
                y_pred.append(pred)
            correct_counts.append(correct)
            incorrect_counts.append(incorrect)
            accuracies.append(correct/len(D))
            errors.append(incorrect/len(D))
            cf_matrices.append(pd.crosstab(y, y_pred, rownames=['Actual'], colnames=['Predicted']))

        cf_matrix = sum(cf_matrices)

        file_name = dataset + '.out'
        with open(file_name, 'w') as file:
            file.write('Overall confusion matrix: ' + '\n')
            file.write(str(cf_matrix) + '\n')
            i = 0
            for label in cf_matrix.index:
                TP = cf_matrix.iloc[i, i]
                FP = np.sum(cf_matrix.iloc[:, i]) - TP
                FN = np.sum(cf_matrix.iloc[i, :]) - TP
                TN = cf_matrix.values.sum() - TP - FP - FN
                file.write('\n' + "For class label '" + str(label) + "': " + '\n')
                file.write('Confusion matrix: ' + '\n')
                temp = [[TP, FP], 
                        [FN, TN]]
                for row in temp:
                    file.write(str(row) + '\n')
                file.write('Recall: ' + str(TP / (TP + FN)) + '\n')
                file.write('Precision: ' + str(TP / (TP + FP)) + '\n')
                i += 1
            file.write('\n' + 'Overall accuracy: ' + str(sum(correct_counts)/sum(len_D)) + '\n')
            file.write('Overall error rate: ' + str(sum(incorrect_counts)/sum(len_D)) + '\n')
            file.write('Average accuracy: ' + str(sum(accuracies)/n) + '\n')
            file.write('Average error rate: ' + str(sum(errors)/n) + '\n')

# python3 validation.py balloon1.csv 10
# python3 validation.py balloon2.csv 10
# python3 validation.py balloon3.csv 10
# python3 validation.py balloon4.csv 10
# python3 validation.py mushroom.csv 10
# python3 validation.py nursery_new.csv 10