import pandas as pd
import math
import json
import sys

class DecisionTreeClassifier():
    def entropy(self, D):
        class_labels_counts = D.iloc[:,-1].value_counts().to_dict()
        total = len(D)

        entropy = 0
        for val in class_labels_counts.values():
            prob = val/total
            entropy += prob * math.log2(prob)
        return -entropy
    
    def selectSplittingAttribute(self, D, A, threshold): # uses information gain ratio
        p0 = self.entropy(D)
        total = len(D)

        entropies = dict.fromkeys(A, 0)
        gains = dict.fromkeys(A, 0)

        for a in A:
            split = dict.fromkeys(D[a].unique(), [])
            for d in split.keys():
                part = D[D[a] == d]
                split[d] = [len(part)/total, self.entropy(part)]
            entropy_split = 0
            for val in split.values():
                entropy_split += val[0] * val[1]
                entropies[a] = entropy_split
                gains[a] = p0 - entropy_split
        best = max(gains, key=gains.get)
        if gains[best] > threshold:
            return best
        else:
            return None
        
    def C45(self, D, A, og_D, threshold, parent_val=None, parent_var=None):
        T = {} 
        class_labels_counts = D.iloc[:,-1].value_counts().to_dict()
        c = max(class_labels_counts, key=class_labels_counts.get)

        # Step 1: check termination conditions
        if len(class_labels_counts.keys()) == 1:
            T['decision'] = list(class_labels_counts.keys())[0]
            T['p'] = og_D[og_D[parent_var] == parent_val].iloc[:,-1].value_counts()[T['decision']]/og_D[parent_var].value_counts()[parent_val]
        elif A == []:
            T['decision'] = c
            T['p'] = og_D[og_D[parent_var] == parent_val].iloc[:,-1].value_counts()[T['decision']]/og_D[parent_var].value_counts()[parent_val]
        # Step 2: select splitting attribute
        else: 
            best = self.selectSplittingAttribute(D, A, threshold)
            if best is None: # no attribute is good for a split
                if (parent_val is None) and (parent_var is None):
                    print('Threshold value too high to even select a root node')
                    exit()
                T['decision'] = c
                T['p'] = og_D[og_D[parent_var] == parent_val].iloc[:,-1].value_counts()[T['decision']]/og_D[parent_var].value_counts()[parent_val]
            # Step 3: tree construction
            else: 
                T['var'] = best
                T['edges'] = []
                for i, v in enumerate(D[best].unique()):
                    D_v = D[D[best] == v]
                    T['edges'].append({})
                    T['edges'][i]['edge'] = {}
                    T['edges'][i]['edge']['value'] = v
                    if not D_v.empty:
                        copy = A.copy()
                        copy.remove(best)

                        T_v = self.C45(D_v, copy, og_D, threshold, v, best) # recursive call
                        if 'decision' in T_v.keys():
                            T['edges'][i]['edge']['leaf'] = T_v
                        else:
                            T['edges'][i]['edge']['node'] = T_v
        return T

if __name__ == '__main__':
    # from command line
    if (len(sys.argv) < 2) or (len(sys.argv) > 3):
        print('Wrong format')
        sys.exit(1)

    csv_file = sys.argv[1]
    before = csv_file.split('.csv')[0]
    dataset = before.split('/')[-1]

    if len(sys.argv) == 3:
        restrictions_file = sys.argv[2]
    else:
        restrictions_file = None

    # getting values
    D = pd.read_csv(csv_file)
    og_D = D.copy()
    if restrictions_file is None: # assumes all
        A = list(D.columns)
    else:
        restrict = open(restrictions_file, 'r').read().split(',')
        restrict = [int(r) for r in restrict]

        A = []
        for index, a in enumerate(D.columns):
            if restrict[index] == 1:
                A.append(a)

    # run C4.5
    classifier = DecisionTreeClassifier()
    T = classifier.C45(D, A, og_D, threshold=0.1)
    T = {'dataset': csv_file, 'node': T}
    with open(dataset + '.json', 'w') as outfile:
        json.dump(T, outfile, indent=4)

# python3 InduceC45.py balloon1.csv balloon1.txt
# python3 InduceC45.py balloon2.csv balloon2.txt
# python3 InduceC45.py balloon3.csv balloon3.txt
# python3 InduceC45.py balloon4.csv balloon4.txt
# python3 InduceC45.py mushroom.csv mushroom.txt
# python3 InduceC45.py nursery_new.csv nursery_new.txt