import pandas as pd
import numpy as np

# create TrainingSetFile.csv and restrictionsFile.txt
def format(csv_path):
    df = pd.read_csv(csv_path)
    df = df.drop([0]).reset_index(drop=True)
    class_var = df.iloc[0, 0]
    df = df.drop([0]).reset_index(drop=True)
    if list(df.columns)[-1] != class_var:
        class_col = df.pop(class_var)
        df[class_var] = class_col
    return df, ('1 ' * (len(df.columns) - 1) + '0').replace(' ', ',')

path = '/Users/sophiapchung/Desktop/CSC466/Lab3Part1/'

balloon1 = format(path + 'adult-stretch.csv')
balloon2 = format(path + 'adult+stretch.csv')
balloon3 = format(path + 'yellow-small.csv')
balloon4 = format(path + 'yellow-small+adult-stretch.csv')

mushroom = format(path + 'agaricus-lepiota.csv')
nursery_new = format(path + 'nursery.csv')

# training files
balloon1[0].to_csv('balloon1.csv', index=False)
balloon2[0].to_csv('balloon2.csv', index=False)
balloon3[0].to_csv('balloon3.csv', index=False)
balloon4[0].to_csv('balloon4.csv', index=False)

mushroom[0].to_csv('mushroom.csv', index=False)
nursery_new[0].to_csv('nursery_new.csv', index=False)

# restriction files
with open('balloon1.txt', 'w') as f:
    f.write(balloon1[1])
with open('balloon2.txt', 'w') as f:
    f.write(balloon2[1])
with open('balloon3.txt', 'w') as f:
    f.write(balloon3[1])
with open('balloon4.txt', 'w') as f:
    f.write(balloon4[1])

with open('mushroom.txt', 'w') as f:
    f.write(mushroom[1])
with open('nursery_new.txt', 'w') as f:
    f.write(nursery_new[1])