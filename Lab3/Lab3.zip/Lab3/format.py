import pandas as pd
import numpy as np

# create TrainingSetFile.csv and restrictionsFile.txt
def format(csv_path):
    df = pd.read_csv(csv_path)
    if csv_path == path + 'crx.data.csv':
        df.columns = ['A' + str(i) for i in range(1, 17)]
        df = df.replace('?', np.NaN)  
    df = df.drop([0]).reset_index(drop=True)
    class_var = df.iloc[0, 0]
    df = df.drop([0]).reset_index(drop=True)
    if list(df.columns)[-1] != class_var:
        class_col = df.pop(class_var)
        df[class_var] = class_col
    if csv_path == path + 'crx.data.csv':
        df = df.dropna() 
        df['A2'] = df['A2'].astype('float64')
        df['A14'] = df['A14'].astype('float64') 
    return df, ('1 ' * (len(df.columns) - 1) + '0').replace(' ', ',')

path = '/Users/sophiapchung/Desktop/CSC466/Lab3Part2/'

iris = format(path + 'iris.data.csv')
credit = format(path + 'crx.data.csv')
heart = format(path + 'heart.csv')

# training files
iris[0].to_csv('iris.csv', index=False)
credit[0].to_csv('credit.csv', index=False)
heart[0].to_csv('heart_new.csv', index=False)

# restriction files
with open('iris.txt', 'w') as f:
    f.write(iris[1])
with open('credit.txt', 'w') as f:
    f.write(credit[1])
with open('heart_new.txt', 'w') as f:
    f.write(heart[1])