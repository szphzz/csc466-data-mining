import pandas as pd
import numpy as np
import sys
import os


class KNNClassifier():
    def __init__(self, D, k, dist): 
        self.D = D
        self.k = k
        self.dist = dist

    def cos_sim(self, doc1, doc2):
        dot_product = np.dot(doc1, doc2)
        norm_doc1 = np.linalg.norm(doc1)
        norm_doc2 = np.linalg.norm(doc2)
        return dot_product / (norm_doc1 * norm_doc2) if norm_doc1 != 0 and norm_doc2 != 0 else 0

    def calc_doc_sizes(self):
        doc_sizes = {}
        for folder_name, sub_folders, doc_names in os.walk('/C50'):
            for doc_name in doc_names:
                doc_path = os.path.join(folder_name, doc_name)
                doc_sizes[doc_name] = os.path.getsize(doc_path)
        return doc_sizes
    
    def okapi(self, id1, id2):
        # dj is len of doc1 in bytes
        doc_sizes = self.calc_doc_sizes()
        avdl = sum(doc_sizes.values())/len(doc_sizes)
        dlj = doc_sizes[self.ground_truth.loc[id1, 'doc']]
        k1 = 1.5 # usually between 1.0 - 2.0 (normalization parameter for dj)
        b = 0.75 # usually 0.75 (normalization parameter for doc length)
        k2 = 500 # usually between 1-1000 (normalization parameter for query q or doc2)

        doc1 = self.D.iloc[id1, 1:-1]
        doc2 = self.D.iloc[id2, 1:-1]

        sim = 0
        for term_id in range(1, self.D.shape[1] - 1):
            qi = self.D.iloc[:, term_id]
            fi1 = doc1[term_id]
            fi2 = doc2[term_id]

            n = self.D.shape[0]
            idf = np.log((n - np.count_nonzero(qi == 0) + 0.5) / (np.count_nonzero(qi == 0) + 0.5))
            tf1 = ((k1 + 1) * fi1) / (k1 * (1 - b + b * dlj/avdl) + fi1)
            tf2 = ((k2 + 1) * fi2) / (k2 + fi2)
            sim += idf * tf1 * tf2
        return sim
    
    def knn(self):
        y_pred = []
        processed_files_count = 0
        for i in range(len(self.D)):
            if processed_files_count >= 250:
                break
            dists = {}
            for j in range(len(self.D)):
                if i != j:
                    if self.dist == 1:
                        dists[j] = self.cos_sim(self.D.iloc[i, 1:-1], self.D.iloc[j, 1:-1])
                    else:
                        dists[j] = self.okapi(i, j)

            knn = dict(sorted(dists.items(), key=lambda x: x[1])[:self.k])

            neighbor_indices = list(knn.keys())
            neighbor_class_preds = [self.D.iloc[index, -1] for index in neighbor_indices]
            most_common_pred = max(set(neighbor_class_preds), key=neighbor_class_preds.count)
            y_pred.append(most_common_pred)
            print(f"predicted for doc {i + 1}")

            processed_files_count += 1
            
        res = pd.DataFrame({'doc': self.D['doc'][:250], 'author': y_pred})
        res.to_csv('authors_knn.csv', index=False)


if __name__ == '__main__':
    D = pd.read_csv(sys.argv[1])
    k = int(sys.argv[2])
    dist = int(sys.argv[3]) # 1 for cosine similarity, 2 for okapi

    ground_truth = pd.read_csv('ground_truth.csv')
    D = pd.merge(D, ground_truth, on='doc', how='outer')

    classifier = KNNClassifier(D, k, dist)
    classifier.knn()

# python3 knnAuthorship.py tfidf_vectorized_docs.csv 10 1
# python3 knnAuthorship.py tf_vectorized_docs.csv 10 2
