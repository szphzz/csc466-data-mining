import pandas as pd
import sys
import numpy as np
import random
from InduceC45 import DecisionTreeClassifier
from classifierEvaluation import classify

class RFClassifier():
    def __init__(self, D, m, k, N, threshold):
        self.D = D
        self.m = m
        self.k = k
        self.N = N
        self.threshold = threshold
       
    def data_selection(self):
        cols = random.sample(list(self.D.columns)[1:-1], self.m) # without replacement
        cols.append(list(self.D.columns)[-1])
        rows = list(np.random.choice(range(len(self.D)), size=self.k, replace=True)) # with replacement
        return self.D.loc[rows, cols]

    def random_forest(self):
        forest = [] # list that contains all the trees
        for i in range(self.N):
            tree_data = self.data_selection()
            og_tree_data = tree_data.copy()
            classifier = DecisionTreeClassifier()
            tree = classifier.C45(tree_data, list(tree_data.columns)[:-1], og_tree_data, self.threshold)
            forest.append(tree)
            print(f"tree {i + 1} complete")
        print('forest complete')

        y_pred = []
        for i in range(len(self.D)):
            tree_preds = []
            for tree in forest:
                pred = classify(self.D.iloc[i, :-1].to_dict(), tree)
                tree_preds.append(pred)
            most_common_pred = max(set(tree_preds), key=tree_preds.count)
            y_pred.append(most_common_pred)
            print(f"predicted for doc {i + 1}")

        res = pd.DataFrame({'doc': self.D['doc'], 'author': y_pred})
        res.to_csv('authors_rf.csv', index=False)

if __name__ == '__main__':
    D = pd.read_csv(sys.argv[1])
    m = int(sys.argv[2])
    k = int(sys.argv[3])
    N = int(sys.argv[4])
    threshold = float(sys.argv[5])

    ground_truth = pd.read_csv('ground_truth.csv')
    D = pd.merge(D, ground_truth, on='doc', how='outer')

    # check that input parameters are valid
    if m > len(list(D.columns)) - 1:
        print('m is larger than number of attributes, please provide a smaller m')
    if k > len(D):
        print('k is larger than number of data points, please provide a smaller k')

    classifier = RFClassifier(D, m, k, N, threshold)
    classifier.random_forest()

# python3 RFAuthorship.py tfidf_vectorized_docs.csv 100 1000 50 0.000001
