import pandas as pd
import sys

def classify(data, T):
    # reached a leaf node, return the classification result
    if 'decision' in T:
        return T['decision']
    
    if 'var' in T:
        value = data.get(T['var'])
    
    if 'edges' in T:
        for dic in T['edges']:
            if dic['edge']['value'] == value:
                return classify(data, dic)
            elif dic['edge']['value'].split()[0] == '<=' and value <= float(dic['edge']['value'].split()[1]):
                return classify(data, dic)
            elif dic['edge']['value'].split()[0] == '>' and value > float(dic['edge']['value'].split()[1]):
                return classify(data, dic)
                
    if ('edge' in T) and ('leaf' in T['edge']):
        return classify(data, T['edge']['leaf'])
    
    if ('edge' in T) and ('value' in T['edge']):
        return classify(data, T['edge']['node'])
            
if __name__ == '__main__':
    
    input = pd.read_csv(sys.argv[1])
    ground_truth = pd.read_csv(sys.argv[2])

    y_pred = input.iloc[:,1]
    y = ground_truth.iloc[:,1]

    author_dict = {author: {'hits': 0, 'strikes': 0, 'misses': 0} for author in y.unique()}

    correct = 0
    incorrect = 0
    for i in range(len(y)):
        if y[i] == y_pred[i]:
            author_dict[y[i]]['hits'] += 1
            correct += 1
        else:
            author_dict[y_pred[i]]['strikes'] += 1
            author_dict[y[i]]['misses'] += 1
            incorrect += 1

    accuracy = correct / len(y)

    print('Total number of documents with correctly predicted authors: ' + str(correct))
    print('Total number of documents with incorrectly predicted authors: ' + str(incorrect))
    print('Overall accuracy: ' + str(accuracy))

    for author, stats in author_dict.items():
        print(f"Author: {author}")
        print(f"Hits: {stats['hits']}")
        print(f"Strikes: {stats['strikes']}")
        print(f"Misses: {stats['misses']}")
        precision_den = stats['hits'] + stats['strikes']
        recall_den = stats['hits'] + stats['misses']

        # Handle the case where precision_denominator is zero
        precision = stats['hits'] / precision_den if precision_den != 0 else 0.0

        # Handle the case where recall_denominator is zero
        recall = stats['hits'] / recall_den if recall_den != 0 else 0.0

        f1_den = precision + recall

        # Check if the denominator of F1 is zero
        if f1_den == 0:
            f1 = 0.0
        else:
            f1 = 2 * (precision * recall) / f1_den

        print(f"Precision: {precision}")
        print(f"Recall: {recall}")
        print(f"F1: {f1}\n")

    cf_matrix = pd.crosstab(y, y_pred, rownames=['Actual'], colnames=['Predicted'])
    cf_matrix.to_csv('cf_matrix.csv', index=False)

# python3 classifierEvaluation.py authors_rf.csv ground_truth.csv
